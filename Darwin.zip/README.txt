Project #5: Darwin
Date: Wed, 7 Nov 2012

Course Name:Object Oriented Programming
Unique:53060

First Name:Roberto 
Last Name:Weller
EID:rw9636
E-mail:rweller@utexas.edu
Estimated number of hours:15
Actual    number of hours:21

Partner First Name:Michael
Partner Last Name:Madden
Partner EID:mm43796
Partner E-mail:m.adamsmadden@gmail.com
Partner Estimated number of hours:10
Partner Actual    number of hours:21

Turnin CS Username:rweller
GitHub ID:robweller8
GitHub Repository Name: cs371p-darwin

Comments: call an ambulance: rover down

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.

